# RFID-Attendance-system
This is the new version of the RFID attendance system that uses NodeMCU or ESP32 with RFID module to send the Card IDs to the website to store the data into the website database
